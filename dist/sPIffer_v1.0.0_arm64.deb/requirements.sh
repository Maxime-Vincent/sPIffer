#!/bin/bash

set -e

sudo apt-get install tshark
sudo apt-get install iptables
sudo apt-get install bridge-utils
sudo apt-get install nodejs
sudo apt-get install npm
sudo npm install dpkg
sudo apt-get install libpam0g-dev
sudo apt-get install debhelper