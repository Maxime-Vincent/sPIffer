# sPIffer Website

## Requirements
### Dependencies

    sudo apt-get install -g nodejs
    sudo apt-get install -g npm
    sudo npm install -g pkg
    sudo apt-get install libpam0g-dev
    "dependencies": {
        "authenticate-pam": "^1.0.5",
        "body-parser": "^1.20.3",
        "ejs": "^3.1.10",
        "express": "^4.21.1",
        "express-session": "^1.18.1",
        "helmet": "^8.0.0"
    }

### Create certificate with openssl

    openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout server.key -out server.crt

### Launch Server

    sudo node server.js

or

    sudo npm start

### To compile the webserver

    pkg . --targets node20-linux-arm64 --output dist/sPIffer

### To execute the compiled webserver

> [!NOTE]
> It may be you need to change the file rights with:  
> sudo chmod +x <path/sPIffer> 

    sudo ./sPIffer
